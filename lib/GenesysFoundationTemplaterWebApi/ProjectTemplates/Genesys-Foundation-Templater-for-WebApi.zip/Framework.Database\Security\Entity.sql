﻿CREATE SCHEMA [Entity]
    AUTHORIZATION [dbo];

