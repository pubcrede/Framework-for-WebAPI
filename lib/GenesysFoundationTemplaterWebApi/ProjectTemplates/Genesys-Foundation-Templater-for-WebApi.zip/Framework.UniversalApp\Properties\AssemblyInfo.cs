﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Genesys Framework Quick-Start for Universal")]
[assembly: AssemblyDescription("Genesys Framework Quick-Start powers your resuable framework for your .Net Core PCL/libraries, Universal x-platform mobile apps and all .Net Full libraries and apps.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Genesys Source")]
[assembly: AssemblyProduct("Genesys Framework Quick-Start for Universal")]
[assembly: AssemblyCopyright("Copyright © 2016 Genesys Source")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("3.0.12")]
[assembly: AssemblyFileVersion("3.0.12")]
[assembly: ComVisible(false)]