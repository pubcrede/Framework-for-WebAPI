﻿--
-- CREATE USER
--
-- Windows Authentication:
--   CREATE USER [FrameworkUser] FOR LOGIN [Domain\FrameworkUser] WITH DEFAULT_SCHEMA=[Sampler]
--   GO
-- SQL Server Mixed Mode:
--   CREATE USER [FrameworkUser] FOR LOGIN [FrameworkUser] WITH DEFAULT_SCHEMA=[Sampler]
--   GO
