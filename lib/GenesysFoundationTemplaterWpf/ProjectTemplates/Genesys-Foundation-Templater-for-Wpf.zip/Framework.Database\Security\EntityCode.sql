﻿CREATE SCHEMA [EntityCode]
    AUTHORIZATION [dbo];

