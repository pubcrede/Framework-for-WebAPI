﻿--
-- CREATE LOGIN
--
-- Windows Authentication:
--  CREATE LOGIN [Domain\FrameworkUser] FROM WINDOWS WITH DEFAULT_DATABASE=[FrameworkData]
--   GO
-- SQL Server Mixed Mode:
--   CREATE LOGIN [FrameworkUser] WITH PASSWORD = 'CA9784C4-2671-41EE-A817-A1EE18373947', DEFAULT_DATABASE=[FrameworkData]
--   GO
