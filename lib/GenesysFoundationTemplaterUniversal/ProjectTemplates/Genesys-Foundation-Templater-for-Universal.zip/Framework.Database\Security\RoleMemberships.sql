﻿--
-- ALTER ROLE
--
-- Windows Authentication and SQL Mixed Mode:
--   ALTER ROLE [db_datareader] ADD MEMBER [FrameworkUser];
--   GO
--   ALTER ROLE [db_datawriter] ADD MEMBER [FrameworkUser];
--   GO

 